let plants = [];
let herbivores = [];
let predators = [];
let ecosystemWidth = 800;
let ecosystemHeight = 600;

const plantEnergy = 50;
const herbivoreEnergy = 100;
const predatorEnergy = 200;
const energyLossRate = 0.5;
const maxSpeed = 2;
const perceptionRadius = 50;
const herbivoreDetectionRadius = 100;
const predatorDetectionRadius = 150;

function setup() {
  createCanvas(ecosystemWidth, ecosystemHeight);
  for (let i = 0; i < 50; i++) {
    plants.push(createVector(random(width), random(height)));
  }
  for (let i = 0; i < 5; i++) {
    herbivores.push(new Herbivore(random(width), random(height)));
  }
  for (let i = 0; i < 3; i++) {
    predators.push(new Predator(random(width), random(height)));
  }
}

function draw() {
  background(220);
  
  fill(0, 255, 0);
  for (let plant of plants) {
    ellipse(plant.x, plant.y, 10, 10);
  }
  
  for (let i = herbivores.length - 1; i >= 0; i--) {
    let herbivore = herbivores[i];
    herbivore.behaviors(plants, predators);
    herbivore.update();
    herbivore.display();
    herbivore.checkBounds();
    if (herbivore.energy <= 0) {
      herbivores.splice(i, 1);
    }
  }
  
  for (let i = predators.length - 1; i >= 0; i--) {
    let predator = predators[i];
    predator.behaviors(herbivores);
    predator.update();
    predator.display();
    predator.checkBounds();
    if (predator.energy <= 0) {
      predators.splice(i, 1);
    }
  }
  
  if (frameCount % 100 === 0) {
    plants.push(createVector(random(width), random(height)));
  }
}

class Herbivore {
  constructor(x, y) {
    this.position = createVector(x, y);
    this.velocity = p5.Vector.random2D();
    this.velocity.setMag(random(1, maxSpeed));
    this.acceleration = createVector();
    this.energy = herbivoreEnergy;
    this.maxSpeed = maxSpeed;
  }
  
  behaviors(plants, predators) {
    let closestPlant = this.findClosestPlant(plants);
    if (closestPlant) {
      let seekForce = this.seek(closestPlant);
      this.applyForce(seekForce);
      if (this.position.dist(closestPlant) < 5) {
        this.consumePlant(plants, closestPlant);
      }
    }
    for (let predator of predators) {
      if (this.position.dist(predator.position) < herbivoreDetectionRadius) {
        let fleeForce = this.flee(predator.position);
        this.applyForce(fleeForce);
      }
    }
  }
  
  consumePlant(plants, plant) {
    for (let i = plants.length - 1; i >= 0; i--) {
      if (plants[i] === plant) {
        this.energy += plantEnergy;
        plants.splice(i, 1);
        break;
      }
    }
  }
  
  findClosestPlant(plants) {
    if (plants.length === 0) {
      return null;
    }
    let closestPlant = plants[0];
    let closestDist = this.position.dist(closestPlant);
    for (let i = 1; i < plants.length; i++) {
      let d = this.position.dist(plants[i]);
      if (d < closestDist) {
        closestDist = d;
        closestPlant = plants[i];
      }
    }
    return closestPlant;
  }
  
  seek(target) {
    let desired = p5.Vector.sub(target, this.position);
    desired.setMag(this.maxSpeed);
    let steer = p5.Vector.sub(desired, this.velocity);
    steer.limit(0.1);
    return steer;
  }
  
  flee(predatorPos) {
    let desired = p5.Vector.sub(this.position, predatorPos);
    desired.setMag(this.maxSpeed);
    let steer = p5.Vector.sub(desired, this.velocity);
    steer.limit(0.1);
    return steer;
  }
  
  applyForce(force) {
    this.acceleration.add(force);
  }
  
  update() {
    this.velocity.add(this.acceleration);
    this.velocity.limit(this.maxSpeed);
    this.position.add(this.velocity);
    this.acceleration.mult(0);
    this.energy -= energyLossRate;
  }

  checkBounds() {
    if (this.position.x < 0) {
      this.position.x = 0;
      this.velocity.x *= -1;
    } else if (this.position.x > width) {
      this.position.x = width;
      this.velocity.x *= -1;
    }
    if (this.position.y < 0) {
      this.position.y = 0;
      this.velocity.y *= -1;
    } else if (this.position.y > height) {
      this.position.y = height;
      this.velocity.y *= -1;
    }
  }
  
  display() {
    fill(0);
    ellipse(this.position.x, this.position.y, 20, 20);
  }
}

class Predator {
  constructor(x, y) {
    this.position = createVector(x, y);
    this.velocity = p5.Vector.random2D();
    this.velocity.setMag(random(1, maxSpeed));
    this.acceleration = createVector();
    this.energy = predatorEnergy;
    this.maxSpeed = maxSpeed;
  }
  
  behaviors(herbivores) {
    let closestHerbivore = this.findClosestHerbivore(herbivores);
    if (closestHerbivore) {
      let seekForce = this.seek(closestHerbivore.position);
      this.applyForce(seekForce);
      if (this.position.dist(closestHerbivore.position) < 5) {
        this.consumeHerbivore(herbivores, closestHerbivore);
      }
    }
  }
  
  consumeHerbivore(herbivores, herbivore) {
    for (let i = herbivores.length - 1; i >= 0; i--) {
      if (herbivores[i] === herbivore) {
        this.energy += herbivores[i].energy; 
        herbivores.splice(i, 1); 
        break;
      }
    }
  }
  
  findClosestHerbivore(herbivores) {
    if (herbivores.length === 0) {
      return null;
    }
    let closestHerbivore = herbivores[0];
    let closestDist = this.position.dist(closestHerbivore.position);
    for (let i = 1; i < herbivores.length; i++) {
      let d = this.position.dist(herbivores[i].position);
      if (d < closestDist) {
        closestDist = d;
        closestHerbivore = herbivores[i];
      }
    }
    return closestHerbivore;
  }
  
  seek(target) {
    let desired = p5.Vector.sub(target, this.position);
    desired.setMag(this.maxSpeed);
    let steer = p5.Vector.sub(desired, this.velocity);
    steer.limit(0.1);
    return steer;
  }
  
  applyForce(force) {
    this.acceleration.add(force);
  }
  
  update() {
    this.velocity.add(this.acceleration);
    this.velocity.limit(this.maxSpeed);
    this.position.add(this.velocity);
    this.acceleration.mult(0);
    this.energy -= energyLossRate;
  }

  checkBounds() {
    if (this.position.x < 0) {
      this.position.x = 0;
      this.velocity.x *= -1;
    } else if (this.position.x > width) {
      this.position.x = width;
      this.velocity.x *= -1;
    }
    if (this.position.y < 0) {
      this.position.y = 0;
      this.velocity.y *= -1;
    } else if (this.position.y > height) {
      this.position.y = height;
      this.velocity.y *= -1;
    }
  }
  
  display() {
    fill(255, 0, 0);
    ellipse(this.position.x, this.position.y, 30, 30);
  }
}